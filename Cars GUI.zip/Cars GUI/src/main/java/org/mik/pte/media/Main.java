package org.mik.pte.media;

public class Main {

	public static void main(String[] args) {
		Controller controller = new Controller();
		controller.Start();
	}

}
